package com.company;

import com.company.Items.Inventory;
import com.company.Models.ChestSlotModel;
import com.company.Models.GameModel;
import com.company.Models.HeadSlotModel;
import com.company.Models.LegSlotModel;
import com.company.Models.PlayerModel;
import com.company.views.GameView;

public class Main {

    public static void main(String[] args) {
    	HeadSlotModel bronzeMedHelm = new HeadSlotModel("Bronze Open Faced Helmet",1,0,0,3,0,20,"A rather pathetic excuse for a helmet");
    	ChestSlotModel bronzePlateBody = new ChestSlotModel("Bronze Plate Body",3,0,3,0,0,55,"Provides poor protection for the body");
    	LegSlotModel bronzePlateLegs = new LegSlotModel("Bronze Plate Legs",2,0,2,0,0,35,"Provdes poor leg protection");
    	LegSlotModel ironPlateLegs = new LegSlotModel("Iron Plate Legs",4,0,5,0,0,35,"Provdes decent leg protection");
    	ChestSlotModel purpleSuit = new ChestSlotModel("Purple Suit",0,0,0,7,3,100,"A stylish purple suit jacket and white tie");
    	LegSlotModel purpleSuitPants = new LegSlotModel("Purple Suit Pants",0,0,0,5,0,45,"A stylish pair of purple suit pants");
    	HeadSlotModel emptySlot = new HeadSlotModel("",0,0,0,0,0,0,"");
    	LegSlotModel kilt = new LegSlotModel("Kilt",0,0,0,0,1,15,"Who would wear this??");
    	
    	Inventory playerInventory = new Inventory();
    	playerInventory.add(ironPlateLegs);
    	playerInventory.add(kilt);
    	
    	Inventory allyInventory = new Inventory();
    	
	    PlayerModel player1 = new PlayerModel(10, "Orazio",bronzeMedHelm,bronzePlateBody,bronzePlateLegs,playerInventory);
	    
	    PlayerModel ally1 = new PlayerModel(8,"Spike",emptySlot,purpleSuit,purpleSuitPants,allyInventory);
	    
	    GameModel gameModel = new GameModel(player1,ally1); // can make it holds several model (enemy, inventory, ecc..)
	    GameView gui = new GameView();
	    GameController controller = new GameController(gameModel, gui);

	    
	    controller.init();
    }
}
