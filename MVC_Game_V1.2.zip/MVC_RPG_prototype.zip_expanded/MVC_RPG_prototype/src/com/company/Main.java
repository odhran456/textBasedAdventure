package com.company;

import com.company.Models.ChestSlotModel;
import com.company.Models.GameModel;
import com.company.Models.HeadSlotModel;
import com.company.Models.LegSlotModel;
import com.company.Models.PlayerModel;
import com.company.views.GameView;

public class Main {

    public static void main(String[] args) {
    	HeadSlotModel bronzeMedHelm = new HeadSlotModel("Bronze Open Faced Helmet",1,0,0,3,0,20,"A rather pathetic excuse for a helmet");
    	ChestSlotModel bronzePlateBody = new ChestSlotModel("Bronze Plate Body",3,0,3,0,0,55,"Provides poor protection for the body");
    	LegSlotModel bronzePlateLegs = new LegSlotModel("Bronze Plate Legs",2,0,2,0,0,35,"Provdes poor leg protection");
    	
	    PlayerModel player1 = new PlayerModel(10, "Orazio",bronzeMedHelm,bronzePlateBody,bronzePlateLegs);
	    GameModel gameModel = new GameModel(player1); // can make it holds several model (enemy, inventory, ecc..)
	    GameView gui = new GameView();
	    GameController controller = new GameController(gameModel, gui);
	    controller.init();
    }
}
