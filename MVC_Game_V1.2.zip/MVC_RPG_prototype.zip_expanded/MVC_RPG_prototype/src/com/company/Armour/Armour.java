package com.company.Armour;

public class Armour{
	private String slotName;
	protected double meleeDefence;
	protected double magicDefence;
	protected double rangeDefence;
	protected double fashion;
	protected double intimidating;
	protected String details;
	
	
	
	public String getSlotName() {
		return this.slotName;
	}
	public double getMeleeDefence() {
		return this.meleeDefence;
	}
	public double getMagicDefence() {
		return this.magicDefence;
	}
	public double getRangeDefence() {
		return this.rangeDefence;
	}
	public double getFashion() {
		return this.fashion;
	}
	public double getIntimidating() {
		return this.intimidating;
	}
	public String getDetails() {
		return this.details;
	}
		
}