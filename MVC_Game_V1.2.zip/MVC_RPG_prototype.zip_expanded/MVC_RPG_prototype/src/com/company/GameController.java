package com.company;

import com.company.Models.GameModel;
import com.company.views.GameGearView;
import com.company.views.GameMenuView;
import com.company.views.GamePlayView;
import com.company.views.GameView;

public class GameController {

    GameModel gameModel;
    GameView gameView;



    public GameController(GameModel gameModel, GameView gameView) {
        this.gameModel = gameModel;
        this.gameView = gameView;
    }

    public void init(){
        menuScreen();
    }


    private void menuScreen(){
        GameMenuView menu = new GameMenuView();
        //OLD WAY WITH ANONYMOUS CLASS
        /*
        menu.getStartButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });*/

        //NEW WAY WITH LAMBDA EXPRESSION
        menu.getStartButton().addActionListener((e)->{
            gameScreen();
        });
        gameView.setViewToRender(menu);
    }

    private void gameScreen(){
        GamePlayView gamePlayView = new GamePlayView();
        
        gamePlayView.getPlayerHP().setText(String.format("HP of %s: %d", gameModel.getPlayerModel().getName(), gameModel.getPlayerModel().getHealthPoints()));
        gamePlayView.getPlayerHelmet().setText(String.format("Helmet of %s: %s", gameModel.getPlayerModel().getName(),gameModel.getPlayerModel().getHeadPieceName()));
        gamePlayView.getAttack().addActionListener((e)-> changePlayerHp(gamePlayView));
        gamePlayView.getGear().addActionListener((e)->{
        	gearScreen();
        });
        gameView.setViewToRender(gamePlayView);
    }

    private void gearScreen() {
    	GameGearView gameGearView = new GameGearView();
    	gameGearView.getHeadPiece().setText(String.format("Head Item: %s", gameModel.getPlayerModel().getHeadPieceName()));
    	gameGearView.getChestPiece().setText(String.format("Chest Item: %s", gameModel.getPlayerModel().getChestPieceName()));
    	gameGearView.getLegPiece().setText(String.format("Leg Item: %s", gameModel.getPlayerModel().getLegPieceName()));
    	gameGearView.getMeleeDefence().setText(String.format("Total Melee Defence: %.0f", gameModel.getPlayerModel().getTotalMeleeDefence()));
    	gameGearView.getMagicDefence().setText(String.format("Total Magic Defence: %.0f", gameModel.getPlayerModel().getTotalMagicDefence()));
    	gameGearView.getRangeDefence().setText(String.format("Total Range Defence: %.0f", gameModel.getPlayerModel().getTotalRangeDefence()));
    	gameView.setViewToRender(gameGearView);
    }

    /*USER INTERACTS ONLY WITH CONTROLLER */
    private void changePlayerHp(GamePlayView view){
        int currentHP = gameModel.getPlayerModel().getHealthPoints();
        gameModel.getPlayerModel().setHealthPoints(currentHP-1);
        if(gameModel.getPlayerModel().getHealthPoints() == 0){
            gameModel.getPlayerModel().resurrect(); //JESUS METHOD
            menuScreen();
        }
        view.getPlayerHP().setText(String.format("HP of %s: %d", gameModel.getPlayerModel().getName(), gameModel.getPlayerModel().getHealthPoints()));
    }
}
