package com.company;

import com.company.Models.GameModel;
import com.company.views.GameGearView;
import com.company.views.GameInventoryView;
import com.company.views.GameMenuView;
import com.company.views.GamePlayView;
import com.company.views.GameView;

public class GameController {

    GameModel gameModel;
    GameView gameView;



    public GameController(GameModel gameModel, GameView gameView) {
        this.gameModel = gameModel;
        this.gameView = gameView;
    }

    public void init(){
        menuScreen();
    }


    private void menuScreen(){
        GameMenuView menu = new GameMenuView();
        //OLD WAY WITH ANONYMOUS CLASS
        /*
        menu.getStartButton().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });*/

        //NEW WAY WITH LAMBDA EXPRESSION
        menu.getStartButton().addActionListener((e)->{
            gameScreen();
        });
        gameView.setViewToRender(menu);
    }

    private void gameScreen(){
        GamePlayView gamePlayView = new GamePlayView();
        
        gamePlayView.getPlayerHP().setText(String.format("%s's HP: %d", gameModel.getPlayerModel().getName(), gameModel.getPlayerModel().getHealthPoints()));
        gamePlayView.getAllyHP().setText(String.format("%s's HP: %d", gameModel.getAllyModel().getName(), gameModel.getAllyModel().getHealthPoints()));
        gamePlayView.getAttack().addActionListener((e)-> changePlayerHp(gamePlayView));
        gamePlayView.getAttack().addActionListener((e)-> changeAllyHp(gamePlayView));
        gamePlayView.getInventory().addActionListener((e)->{
        	inventoryScreen();
        });
        gamePlayView.getGear().addActionListener((e)->{
        	gearScreen();
        });
        gameView.setViewToRender(gamePlayView);
    }

    private void inventoryScreen() {
    	GameInventoryView gameInventoryView = new GameInventoryView();
    	gameInventoryView.getBackButton().addActionListener((e)->{
    		gameScreen();
    	});
    	gameInventoryView.getSlot1().setText(String.format("%s", gameModel.getPlayerModel().getInventory().printSlot1()));
    	gameInventoryView.getSlot2().setText(String.format("%s", gameModel.getPlayerModel().getCharacterInventory()));
    	gameView.setViewToRender(gameInventoryView);
	}

	private void gearScreen() {
    	GameGearView gameGearView = new GameGearView();
    	gameGearView.getHeadPiece().setText(String.format("Head Item: %s", gameModel.getPlayerModel().getHeadPieceName()));
    	gameGearView.getChestPiece().setText(String.format("Chest Item: %s", gameModel.getPlayerModel().getChestPieceName()));
    	gameGearView.getLegPiece().setText(String.format("Leg Item: %s", gameModel.getPlayerModel().getLegPieceName()));
    	gameGearView.getMeleeDefence().setText(String.format("Total Melee Defence: %.0f", gameModel.getPlayerModel().getTotalMeleeDefence()));
    	gameGearView.getMagicDefence().setText(String.format("Total Magic Defence: %.0f", gameModel.getPlayerModel().getTotalMagicDefence()));
    	gameGearView.getRangeDefence().setText(String.format("Total Range Defence: %.0f", gameModel.getPlayerModel().getTotalRangeDefence()));
    	gameGearView.getFashion().setText(String.format("Total Fashion: %.0f", gameModel.getPlayerModel().getTotalFashion()));
    	gameGearView.getIntimidating().setText(String.format("Total Intimidating: %.0f", gameModel.getPlayerModel().getTotalIntimidating()));
    	gameGearView.getBackButton().addActionListener((e)-> {
    		gameScreen();
    	});
    	gameView.setViewToRender(gameGearView);
    }

    /*USER INTERACTS ONLY WITH CONTROLLER */
    private void changePlayerHp(GamePlayView view){
        int currentHP = gameModel.getPlayerModel().getHealthPoints();
        gameModel.getPlayerModel().setHealthPoints(currentHP-1);
        if(gameModel.getPlayerModel().getHealthPoints() == 0){
            gameModel.getPlayerModel().resurrect(); //JESUS METHOD
            menuScreen();
        }
        view.getPlayerHP().setText(String.format("%s's HP: %d", gameModel.getPlayerModel().getName(), gameModel.getPlayerModel().getHealthPoints()));
    }
    
    private void changeAllyHp(GamePlayView view){
        int currentHP = gameModel.getAllyModel().getHealthPoints();
        gameModel.getAllyModel().setHealthPoints(currentHP-1);
        if(gameModel.getAllyModel().getHealthPoints() == 0){
            gameModel.getAllyModel().resurrect(); //JESUS METHOD
            menuScreen();
        }
        view.getAllyHP().setText(String.format("%s's HP: %d", gameModel.getAllyModel().getName(), gameModel.getAllyModel().getHealthPoints()));
    }
    
    private void equipGear(GameGearView view) {
    	//TO DO
    	/* I think this method should unequip whatever current item you have in a 
    	 * particular slot and then equip what you wanted to equip from your inventory 
    	 * in that slot. I think maybe the use of enums for the armour might be helpful?
    	 * I am going to have an equip button next to items in the inventory view and this
    	 * is what they'll do!!
    	 * 
    	 * Also, I want humanoids to have the OPTION to have one head slot, chest
    	 * slot and leg slot equipped, not that they must. Currently they must as 
    	 * the constructor takes one of each. I must fix that!!
    	 */
    }
}
