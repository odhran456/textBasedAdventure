package com.company.Models;

import com.company.Models.PlayerModel;

public class GameModel {

    private PlayerModel playerModel;

    public GameModel(PlayerModel playerModel) {
        this.playerModel = playerModel;
    }

    public PlayerModel getPlayerModel() {
        return playerModel;
    }
}
