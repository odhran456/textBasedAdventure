package com.company.Models;

import com.company.Models.PlayerModel;

public class GameModel {

    private PlayerModel playerModel;
    private PlayerModel allyModel;

    public GameModel(PlayerModel playerModel, PlayerModel allyModel) {
        this.playerModel = playerModel;
        this.allyModel = allyModel;
    }

    public PlayerModel getPlayerModel() {
        return playerModel;
    }

	public PlayerModel getAllyModel() {
		return allyModel;
	}

	public void setAllyModel(PlayerModel allyModel) {
		this.allyModel = allyModel;
	}
    
    
}
