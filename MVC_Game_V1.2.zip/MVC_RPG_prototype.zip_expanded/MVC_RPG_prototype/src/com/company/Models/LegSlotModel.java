package com.company.Models;

import com.company.Armour.Armour;

public class LegSlotModel extends Armour{
	private String legSlotName;
	private String examine;
	
	public LegSlotModel (String legSlotName, double meleeDefence, double magicDefence,
			double rangeDefence, double fashion, double intimidating, double value, String examine) {
		this.legSlotName = legSlotName;
		this.meleeDefence = meleeDefence;
		this.magicDefence = magicDefence;
		this.rangeDefence = rangeDefence;
		this.fashion = fashion;
		this.intimidating = intimidating;
		//this.value = value;
		this.examine = examine;
	}
	
	public String getSlotName() {
		return legSlotName;
	}
	
	public String getItemName() {
		return legSlotName;
	}
	
	
//	public String getDetails() {
//		return "Item:	" + legSlotName + "\n" + "Stats:" + 
//				"	melee def: " + getMeleeDefence() + "\n" +
//				"	magic def: " + getMagicDefence() + "\n" +
//				"	ranged def: " + getRangeDefence() + "\n" +
//				"	Value: " + getValue();
//	}
	
	public String examine() {
		return examine;
	}
	
}