package com.company.Models;

import com.company.Characters.Humanoid;
import com.company.Items.Inventory;

public class PlayerModel extends Humanoid{

    public PlayerModel(int healthPoints, String name, HeadSlotModel headPiece, ChestSlotModel chestPiece, LegSlotModel legPiece, Inventory inv) {
        super(healthPoints, name, headPiece, chestPiece, legPiece,inv);
    }

    public void resurrect(){
        setHealthPoints(10);
    }
}
