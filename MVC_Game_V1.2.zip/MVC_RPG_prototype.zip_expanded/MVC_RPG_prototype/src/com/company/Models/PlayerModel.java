package com.company.Models;

import com.company.Characters.Entity;

public class PlayerModel extends Entity{

    public PlayerModel(int healthPoints, String name, HeadSlotModel headPiece, ChestSlotModel chestPiece, LegSlotModel legPiece) {
        super(healthPoints, name, headPiece, chestPiece, legPiece);
    }

    public void resurrect(){
        setHealthPoints(10);
    }
}
