package com.company.Models;

import com.company.Items.Armour;

public class HeadSlotModel extends Armour{
	private String headSlotName;
	private String examine;
	
	public HeadSlotModel (String headSlotName, double meleeDefence, double magicDefence,
			double rangeDefence, double fashion, double intimidating, double value, String examine) {
		this.value = value;
		this.headSlotName = headSlotName;
		this.meleeDefence = meleeDefence;
		this.magicDefence = magicDefence;
		this.rangeDefence = rangeDefence;
		this.fashion = fashion;
		this.intimidating = intimidating;
		this.examine = examine;
	}
	
	
	
	public String getItemName() {
		return headSlotName;
	}
	
	
//	public String getDetails() {
//		return "Item:	" + headSlotName + "\n" + "Stats:" + 
//				"	melee def: " + getMeleeDefence() + "\n" +
//				"	magic def: " + getMagicDefence() + "\n" +
//				"	ranged def: " + getRangeDefence() + "\n" +
//				"	Value: " + getValue();
//	}
	
	public String examine() {
		return examine;
	}


	
}