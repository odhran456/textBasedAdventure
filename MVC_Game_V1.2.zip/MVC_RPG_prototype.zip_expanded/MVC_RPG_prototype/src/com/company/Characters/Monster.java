package com.company.Characters;

public class Monster extends Entity {
	private double magicDef;
	private double rangeDef;
	private double meleeDef;
	
	public Monster(int healthPoints, String name,double magicDef,double rangeDef, double meleeDef) {
		super(healthPoints, name);
		this.magicDef = magicDef;
		this.meleeDef = meleeDef;
		this.rangeDef = rangeDef;
	}

	public double getTotalMeleeDefence() {
		return this.meleeDef;
	}

	public double getTotalMagicDefence() {
		return this.magicDef;
	}

	public double getTotalRangeDefence() {
		return this.rangeDef;
	}
}
