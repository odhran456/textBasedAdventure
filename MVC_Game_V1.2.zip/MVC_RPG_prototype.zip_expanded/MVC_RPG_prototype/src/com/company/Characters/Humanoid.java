package com.company.Characters;

import com.company.Items.Inventory;
import com.company.Models.ChestSlotModel;
import com.company.Models.HeadSlotModel;
import com.company.Models.LegSlotModel;

public class Humanoid extends Entity{
	
	private Inventory characterInventory;
	private HeadSlotModel headPiece;
	private ChestSlotModel chestPiece;
	private LegSlotModel legPiece;
	
	public Humanoid (int healthPoints, String name,HeadSlotModel headPiece, ChestSlotModel chestPiece, LegSlotModel legPiece, Inventory characterInventory) {
		super(healthPoints, name);
		this.characterInventory = characterInventory;
		this.headPiece = headPiece;
		this.chestPiece = chestPiece;
		this.legPiece = legPiece;
	}
	
	public HeadSlotModel getHeadPiece() {
		return headPiece;
	}

	public void setHeadPiece(HeadSlotModel headPiece) {
		this.headPiece = headPiece;
	}
	
	public String getHeadPieceName() {
		return headPiece.getItemName();
	}

	public ChestSlotModel getChestPiece() {
		return chestPiece;
	}

	public void setChestPiece(ChestSlotModel chestPiece) {
		this.chestPiece = chestPiece;
	}
	
	public String getChestPieceName() {
		return chestPiece.getSlotName();
	}

	public LegSlotModel getLegPiece() {
		return legPiece;
	}

	public void setLegPiece(LegSlotModel legPiece) {
		this.legPiece = legPiece;
	}
	
	public String getLegPieceName() {
		return legPiece.getSlotName();
	}
	
	public Inventory getInventory() {
		return characterInventory;
	}
	
	public String getCharacterInventory() {
		return characterInventory.printItems();
	}
	
	public double getTotalMeleeDefence() {
		return headPiece.getMeleeDefence() + chestPiece.getMeleeDefence() + legPiece.getMeleeDefence();
	}
	
	public double getTotalMagicDefence() {
		return headPiece.getMagicDefence() + chestPiece.getMagicDefence() + legPiece.getMagicDefence();
	}
	
	public double getTotalRangeDefence() {
		return headPiece.getRangeDefence() + chestPiece.getRangeDefence() + legPiece.getRangeDefence();
	}
	
	public double getTotalFashion() {
		return headPiece.getFashion() + chestPiece.getFashion() + legPiece.getFashion();
	}
	
	public double getTotalIntimidating() {
		return headPiece.getIntimidating() + chestPiece.getIntimidating() + legPiece.getIntimidating();
	}
}