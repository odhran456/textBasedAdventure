package com.company.Characters;

import com.company.Models.ChestSlotModel;
import com.company.Models.HeadSlotModel;
import com.company.Models.LegSlotModel;

public class Entity {
	
	private HeadSlotModel headPiece;
	private ChestSlotModel chestPiece;
	private LegSlotModel legPiece;
    public int healthPoints;
    public String name;

    public Entity(int healthPoints, String name,HeadSlotModel headPiece, ChestSlotModel chestPiece, LegSlotModel legPiece) {
    	this.headPiece = headPiece;;
    	this.chestPiece = chestPiece;
    	this.legPiece = legPiece;
        this.healthPoints = healthPoints;
        this.name = name;
    }

    public int getHealthPoints() {
        return this.healthPoints;
    }

    public String getName() {
        return this.name;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public void setName(String name) {
        this.name = name;
    }

	public HeadSlotModel getHeadPiece() {
		return headPiece;
	}

	public void setHeadPiece(HeadSlotModel headPiece) {
		this.headPiece = headPiece;
	}
	
	public String getHeadPieceName() {
		return headPiece.getSlotName();
	}

	public ChestSlotModel getChestPiece() {
		return chestPiece;
	}

	public void setChestPiece(ChestSlotModel chestPiece) {
		this.chestPiece = chestPiece;
	}
	
	public String getChestPieceName() {
		return chestPiece.getSlotName();
	}

	public LegSlotModel getLegPiece() {
		return legPiece;
	}

	public void setLegPiece(LegSlotModel legPiece) {
		this.legPiece = legPiece;
	}
	
	public String getLegPieceName() {
		return legPiece.getSlotName();
	}
	
	public double getTotalMeleeDefence() {
		return headPiece.getMeleeDefence() + chestPiece.getMeleeDefence() + legPiece.getMeleeDefence();
	}
	
	public double getTotalMagicDefence() {
		return headPiece.getMagicDefence() + chestPiece.getMagicDefence() + legPiece.getMagicDefence();
	}
	
	public double getTotalRangeDefence() {
		return headPiece.getRangeDefence() + chestPiece.getRangeDefence() + legPiece.getRangeDefence();
	}
}
