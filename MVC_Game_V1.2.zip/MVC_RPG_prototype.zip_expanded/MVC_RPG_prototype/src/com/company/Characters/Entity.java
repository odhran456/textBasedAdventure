package com.company.Characters;


public abstract class Entity {
	

    public int healthPoints;
    public String name;

    public Entity(int healthPoints, String name) {
    	
        this.healthPoints = healthPoints;
        this.name = name;
    }

    public int getHealthPoints() {
        return this.healthPoints;
    }

    public String getName() {
        return this.name;
    }

    public void setHealthPoints(int healthPoints) {
        this.healthPoints = healthPoints;
    }

    public void setName(String name) {
        this.name = name;
    }

	
	public abstract double getTotalMeleeDefence();
	
	public abstract double getTotalMagicDefence();
	
	public abstract double getTotalRangeDefence();
}
