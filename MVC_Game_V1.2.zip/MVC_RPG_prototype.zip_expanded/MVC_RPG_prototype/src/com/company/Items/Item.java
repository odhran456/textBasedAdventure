package com.company.Items;

public class Item {
	protected double value;
	protected String itemName;
	private String details;
	
	
	
	public double getValue() {
		return this.value;
	}
	public String getItemName() {
		return this.itemName;
	}
	public String getDetails() {
		return this.details;
	}
	

}
