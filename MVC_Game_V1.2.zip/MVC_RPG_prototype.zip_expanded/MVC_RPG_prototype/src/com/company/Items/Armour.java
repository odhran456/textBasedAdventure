package com.company.Items;

public class Armour extends Item{
	protected double meleeDefence;
	protected double magicDefence;
	protected double rangeDefence;
	protected double fashion;
	protected double intimidating;
	protected String details;
	
	
	
	
	public double getMeleeDefence() {
		return this.meleeDefence;
	}
	public double getMagicDefence() {
		return this.magicDefence;
	}
	public double getRangeDefence() {
		return this.rangeDefence;
	}
	public double getFashion() {
		return this.fashion;
	}
	public double getIntimidating() {
		return this.intimidating;
	}
	
		
}