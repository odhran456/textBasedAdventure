package com.company.Items;

import java.util.ArrayList;

public class Inventory{
	
	
	private ArrayList<Item> items;

	public Inventory() {
		items = new ArrayList<Item>(); 	
	}
	
	public void add(Item item){
		if (items.size() < 11) {
			items.add(item);
		}
		else {
			System.out.println("Not enough space in inventory. Drop items to pick up");
		}
	}
	
	public String printItems() {
		String inventory = "";
		for (int i=0; i < items.size(); i++) {
			inventory += items.get(i).getItemName()+ "\n";
		}
		return inventory;
	}
	
	public String printSlot1() {
		return items.get(0).itemName;
	}
	
	public String printStatsItem() {
		String statsInventory = "";
		for (int i=0; i < items.size(); i++) {
			statsInventory += items.get(i).getDetails() + "\n"; 
		}
		return statsInventory;
	}
	
	
}