package com.company.views;

import javax.swing.*;
import java.awt.*;

public class GameView extends JFrame {

    JPanel viewToRender;

    public GameView() {
    	//setLayout(null);
        setSize(900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
        setResizable(false);
    }

    /*SETTERS*/

    public void setViewToRender(JPanel viewToRender) {
        if(this.viewToRender != null){
            remove(this.viewToRender);
        }
        this.viewToRender = viewToRender;
        this.add(viewToRender, BorderLayout.CENTER);
        this.revalidate();
        this.repaint();
    }
}
