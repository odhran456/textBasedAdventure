package com.company.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GameInventoryView extends JPanel{
	
	JLabel slot1,slot2,slot3,slot4,slot5,slot6,slot7,slot8,slot9,slot10;
    JPanel InventoryPanel,playerPanel;
    JButton backButton;
    
    Font normalFont = new Font("Times New Roman",Font.PLAIN,30);

    public GameInventoryView() {
        super(new BorderLayout());

        initGUI();
    }
   
    private void initGUI(){
    	
    	playerPanel = new JPanel();
    	BoxLayout topPanel = new BoxLayout(playerPanel, BoxLayout.X_AXIS);
    	playerPanel.setLayout(topPanel);
    	this.add(playerPanel,BorderLayout.NORTH);
    	
    	this.backButton = new JButton(" > Back");
    	playerPanel.add(backButton);
    	
    	InventoryPanel = new JPanel();
		InventoryPanel.setBackground(Color.DARK_GRAY);
		InventoryPanel.setLayout(new GridLayout(5,2));
		//playerPanel.setBounds(300, 300, 300, 300);
		this.add(InventoryPanel,BorderLayout.CENTER);
    	
        
        this.slot1 = new JLabel();
        slot1.setFont(normalFont);
        slot1.setForeground(Color.white);
        InventoryPanel.add(slot1);
        
        this.slot2 = new JLabel();
        slot2.setFont(normalFont);
        slot2.setForeground(Color.white);
        InventoryPanel.add(slot2);
//        
//        this.slot3 = new JLabel();
//        slot3.setFont(normalFont);
//        slot3.setForeground(Color.white);
//        InventoryPanel.add(slot3);
//        
//        this.slot4 = new JLabel();
//        slot4.setFont(normalFont);
//        slot4.setForeground(Color.white);
//        InventoryPanel.add(slot4);
//        
//        this.slot5 = new JLabel();
//        slot5.setFont(normalFont);
//        slot5.setForeground(Color.white);
//        InventoryPanel.add(slot5);
//        
//        this.slot6 = new JLabel();
//        slot6.setFont(normalFont);
//        slot6.setForeground(Color.white);
//        InventoryPanel.add(slot6);
//        
//        this.slot7 = new JLabel();
//        slot7.setFont(normalFont);
//        slot7.setForeground(Color.white);
//        InventoryPanel.add(slot7);
//        
//        this.slot8 = new JLabel();
//        slot8.setFont(normalFont);
//        slot8.setForeground(Color.white);
//        InventoryPanel.add(slot8);
//        
//        this.slot9 = new JLabel();
//        slot9.setFont(normalFont);
//        slot9.setForeground(Color.white);
//        InventoryPanel.add(slot9);
//        
//        this.slot10 = new JLabel();
//        slot10.setFont(normalFont);
//        slot10.setForeground(Color.white);
//        InventoryPanel.add(slot10);
        
        setSize(200,200);
        this.setVisible(true);
    }


    /*GETTERS*/

    public JLabel getSlot1() {
    	return slot1;
    }
    
    public JLabel getSlot2() {
    	return slot2;
    }
//    
//    public JLabel getSlot3() {
//    	return slot3;
//    }
//    
//    public JLabel getSlot4() {
//    	return slot4;
//    }
//    
//    public JLabel getSlot5() {
//    	return slot5;
//    }
//    
//    public JLabel getSlot6() {
//    	return slot6;
//    }
//    
//    public JLabel getSlot7() {
//    	return slot7;
//    }
//    
//    public JLabel getSlot8() {
//    	return slot8;
//    }
//    
//    public JLabel getSlot9() {
//    	return slot9;
//    }
//    
//    public JLabel getSlot10() {
//    	return slot10;
//    }
    public JButton getBackButton() {
    	return backButton;
    }
}
