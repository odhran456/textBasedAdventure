package com.company.views;

import javax.swing.*;
import java.awt.*;

public class GameMenuView extends JPanel {

	JPanel titlePanel;
    JButton startButton;
    JLabel titleNameLabel;
	Font titleFont = new Font("Times New Roman",Font.PLAIN,90);
    Font normalFont = new Font("Times New Roman",Font.PLAIN,30);

    public GameMenuView() {
        super(new BorderLayout());
    	initGUI();
        setMinimumSize(new Dimension(300,300));
    }

    private void initGUI(){
        
    	titlePanel = new JPanel();
    	
    	
        titleNameLabel = new JLabel("Adventure");
		titleNameLabel.setForeground(Color.DARK_GRAY);
		titleNameLabel.setFont(titleFont);
		//titleNameLabel.setBounds(300,300,300,300);
		//add(titleNameLabel);
		//add(titleNameLabel, BorderLayout.CENTER);
		titlePanel.add(titleNameLabel);
		add(titlePanel, BorderLayout.CENTER);
		
        startButton = new JButton("Start");
        startButton.setBackground(Color.black);
		startButton.setForeground(Color.white);
		startButton.setFont(normalFont);
		startButton.setFocusPainted(false);
		//startButton.setBounds(0, 0, 300, 300);
        //add(startButton);
		add(startButton, BorderLayout.SOUTH);
    }

    /*GETTERS*/

    public JButton getStartButton() {
        return startButton;
    }
}
