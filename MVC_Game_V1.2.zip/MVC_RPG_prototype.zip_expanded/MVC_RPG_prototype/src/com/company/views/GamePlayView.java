package com.company.views;

import javax.swing.*;
import java.awt.*;

public class GamePlayView extends JPanel {
    JLabel playerHP,AllyHPLabel,playerHelmet;
    JPanel playerPanel;
    JButton attack,gear;
    Font normalFont = new Font("Times New Roman",Font.PLAIN,30);

    public GamePlayView() {
        super(new BorderLayout());

        initGUI();
    }
   
    private void initGUI(){
    	
    	/*TOP PANEL FOR HP STUFF*/
    	playerPanel = new JPanel();
		playerPanel.setBackground(Color.red);
		playerPanel.setLayout(new GridLayout(1,4));
		//playerPanel.setBounds(300, 300, 300, 300);
		this.add(playerPanel,BorderLayout.NORTH);
    	
        /*LABEL HP PLAYER*/
        this.playerHP = new JLabel();
        playerHP.setFont(normalFont);
        playerHP.setForeground(Color.white);
        playerPanel.add(playerHP);

        /*ALLY HP MESSAGE*/
//        AllyHPLabel = new JLabel("Ally's HP: ");
//		AllyHPLabel.setFont(normalFont);
//		AllyHPLabel.setForeground(Color.white);
//		playerPanel.add(AllyHPLabel);
        
		/*LABEL FOR HELMET*/
		this.playerHelmet = new JLabel();
		playerHelmet.setFont(normalFont);
		playerHelmet.setForeground(Color.white);
		playerPanel.add(playerHelmet);

		/*Button to go to gear page*/
		this.gear = new JButton("> Gear");
		this.add(gear,BorderLayout.WEST);
		
        /*TEST BUTTON*/
        this.attack = new JButton("-- life");
        this.add(attack,BorderLayout.SOUTH);

        setSize(200,200);
        this.setVisible(true);
    }


    /*GETTERS*/

    public JLabel getPlayerHelmet() {
    	return playerHelmet;
    }
    
    public JLabel getPlayerHP() {
        return playerHP;
    }

    public JButton getAttack() {
        return attack;
    }
    
    public JButton getGear() {
    	return gear;
    }
}
