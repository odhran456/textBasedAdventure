package com.company.views;

import javax.swing.*;
import java.awt.*;

public class GamePlayView extends JPanel {
    JLabel playerHP,AllyHP;
    JPanel playerPanel, optionsPanel;
    JButton attack,gear,inventory;
    Font normalFont = new Font("Times New Roman",Font.PLAIN,30);

    public GamePlayView() {
        super(new BorderLayout());

        initGUI();
    }
   
    private void initGUI(){
    	
    	/*TOP PANEL FOR HP STUFF*/
    	playerPanel = new JPanel();
		playerPanel.setBackground(Color.GRAY);
		playerPanel.setLayout(new GridLayout(1,3));
		//playerPanel.setBounds(300, 300, 300, 300);
		this.add(playerPanel,BorderLayout.NORTH);
		
		optionsPanel = new JPanel();
		optionsPanel.setBackground(Color.gray);
		BoxLayout optionsLayout = new BoxLayout(optionsPanel, BoxLayout.Y_AXIS);
		optionsPanel.setLayout(optionsLayout);
		this.add(optionsPanel,BorderLayout.WEST);
    	
        /*LABEL HP PLAYER*/
        this.playerHP = new JLabel();
        playerHP.setFont(normalFont);
        playerHP.setForeground(Color.white);
        playerPanel.add(playerHP);

        /*ALLY HP MESSAGE*/
        AllyHP = new JLabel();
		AllyHP.setFont(normalFont);
		AllyHP.setForeground(Color.white);
		playerPanel.add(AllyHP);
        

		/*Button to go to gear page*/
		this.gear = new JButton("> Gear");
		optionsPanel.add(gear);
		
		this.inventory = new JButton("> Inventory");
		optionsPanel.add(inventory);
		
        /*TEST BUTTON*/
        this.attack = new JButton("-- life");
        optionsPanel.add(attack);

        setSize(200,200);
        this.setVisible(true);
        
        
    }


    /*GETTERS*/

    public JLabel getAllyHP() {
    	return AllyHP;
    }
    
    public JLabel getPlayerHP() {
        return playerHP;
    }

    public JButton getAttack() {
        return attack;
    }
    
    public JButton getGear() {
    	return gear;
    }
    
    public JButton getInventory() {
    	return inventory;
    }
}
