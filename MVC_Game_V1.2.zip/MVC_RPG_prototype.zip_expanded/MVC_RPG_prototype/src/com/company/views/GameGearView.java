package com.company.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GameGearView extends JPanel{
	
	JLabel headPiece,chestPiece,legPiece, meleeDefence, magicDefence, rangeDefence, fashion, intimidating;
    JPanel gearPanel, statsPanel,playerPanel;
    JButton backButton;
    
    Font normalFont = new Font("Times New Roman",Font.PLAIN,30);

    public GameGearView() {
        super(new BorderLayout());

        initGUI();
    }
   
    private void initGUI(){
    	
    	playerPanel = new JPanel();
    	BoxLayout topPanel = new BoxLayout(playerPanel, BoxLayout.X_AXIS);
    	playerPanel.setLayout(topPanel);
    	this.add(playerPanel,BorderLayout.NORTH);
    	
    	this.backButton = new JButton(" > Back");
    	playerPanel.add(backButton);
    	
    	gearPanel = new JPanel();
		gearPanel.setBackground(Color.DARK_GRAY);
		gearPanel.setLayout(new GridLayout(3,1));
		//playerPanel.setBounds(300, 300, 300, 300);
		this.add(gearPanel,BorderLayout.WEST);
    	
		statsPanel = new JPanel();
		statsPanel.setLayout(new GridLayout(5,1));
		this.add(statsPanel,BorderLayout.EAST);
		
        /*LABEL HEAD PIECE*/
        this.headPiece = new JLabel();
        headPiece.setFont(normalFont);
        headPiece.setForeground(Color.white);
        gearPanel.add(headPiece);
        
        /*LABEL CHEST PIECE*/
        this.chestPiece = new JLabel();
        chestPiece.setFont(normalFont);
        chestPiece.setForeground(Color.white);
        gearPanel.add(chestPiece);
        
        /*LABEL LEG PIECE*/
        this.legPiece = new JLabel();
        legPiece.setFont(normalFont);
        legPiece.setForeground(Color.white);
        gearPanel.add(legPiece);
        
        /*TOTAL MELEE DEFENCE*/
        this.meleeDefence = new JLabel();
        meleeDefence.setFont(normalFont);
        meleeDefence.setForeground(Color.DARK_GRAY);
        statsPanel.add(meleeDefence);

        /*TOTAL MAGIC DEFENCE*/
        this.magicDefence = new JLabel();
        magicDefence.setFont(normalFont);
        magicDefence.setForeground(Color.DARK_GRAY);
        statsPanel.add(magicDefence);
        
        /*TOTAL RANGED DEFENCE*/
        this.rangeDefence = new JLabel();
        rangeDefence.setFont(normalFont);
        rangeDefence.setForeground(Color.DARK_GRAY);
        statsPanel.add(rangeDefence);
        
        this.fashion = new JLabel();
        fashion.setFont(normalFont);
        fashion.setForeground(Color.DARK_GRAY);
        statsPanel.add(fashion);
        
        this.intimidating = new JLabel();
        intimidating.setFont(normalFont);
        intimidating.setForeground(Color.DARK_GRAY);
        statsPanel.add(intimidating);
        
        setSize(200,200);
        this.setVisible(true);
    }


    /*GETTERS*/

    public JLabel getHeadPiece() {
    	return headPiece;
    }
    
    public JLabel getChestPiece() {
        return chestPiece;
    }

    public JLabel getLegPiece() {
        return legPiece;
    }
    
    public JLabel getMeleeDefence() {
    	return meleeDefence;
    }
    
    public JLabel getMagicDefence() {
    	return magicDefence;
    }
    
    public JLabel getRangeDefence() {
    	return rangeDefence;
    }
    
    public JLabel getFashion() {
    	return fashion;
    }
    
    public JLabel getIntimidating() {
    	return intimidating;
    }
    
    public JButton getBackButton() {
    	return backButton;
    }
}
