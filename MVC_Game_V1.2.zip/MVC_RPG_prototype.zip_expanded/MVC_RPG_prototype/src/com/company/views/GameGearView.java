package com.company.views;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GameGearView extends JPanel{
	
	JLabel headPiece,chestPiece,legPiece, meleeDefence, magicDefence, rangeDefence;
    JPanel playerPanel, statsPanel;
    
    Font normalFont = new Font("Times New Roman",Font.PLAIN,30);

    public GameGearView() {
        super(new BorderLayout());

        initGUI();
    }
   
    private void initGUI(){
    	
    	/*TOP PANEL FOR HP STUFF*/
    	playerPanel = new JPanel();
		playerPanel.setBackground(Color.red);
		playerPanel.setLayout(new GridLayout(3,1));
		//playerPanel.setBounds(300, 300, 300, 300);
		this.add(playerPanel,BorderLayout.NORTH);
    	
		statsPanel = new JPanel();
		statsPanel.setLayout(new GridLayout(3,1));
		this.add(statsPanel,BorderLayout.CENTER);
		
        /*LABEL HEAD PIECE*/
        this.headPiece = new JLabel();
        headPiece.setFont(normalFont);
        headPiece.setForeground(Color.white);
        playerPanel.add(headPiece);
        
        /*LABEL CHEST PIECE*/
        this.chestPiece = new JLabel();
        chestPiece.setFont(normalFont);
        chestPiece.setForeground(Color.white);
        playerPanel.add(chestPiece);
        
        /*LABEL LEG PIECE*/
        this.legPiece = new JLabel();
        legPiece.setFont(normalFont);
        legPiece.setForeground(Color.white);
        playerPanel.add(legPiece);
        
        /*TOTAL MELEE DEFENCE*/
        this.meleeDefence = new JLabel();
        meleeDefence.setFont(normalFont);
        meleeDefence.setForeground(Color.DARK_GRAY);
        statsPanel.add(meleeDefence);

        /*TOTAL MAGIC DEFENCE*/
        this.magicDefence = new JLabel();
        magicDefence.setFont(normalFont);
        magicDefence.setForeground(Color.DARK_GRAY);
        statsPanel.add(magicDefence);
        
        /*TOTAL RANGED DEFENCE*/
        this.rangeDefence = new JLabel();
        rangeDefence.setFont(normalFont);
        rangeDefence.setForeground(Color.DARK_GRAY);
        statsPanel.add(rangeDefence);
        
        setSize(200,200);
        this.setVisible(true);
    }


    /*GETTERS*/

    public JLabel getHeadPiece() {
    	return headPiece;
    }
    
    public JLabel getChestPiece() {
        return chestPiece;
    }

    public JLabel getLegPiece() {
        return legPiece;
    }
    
    public JLabel getMeleeDefence() {
    	return meleeDefence;
    }
    
    public JLabel getMagicDefence() {
    	return magicDefence;
    }
    
    public JLabel getRangeDefence() {
    	return rangeDefence;
    }
}
